
<!DOCTYPE html>
<html lang="en">
<head>
	<title align="center" >About Us</title>
	<link rel="stylesheet" href="../css/home.css">
</head>
<body>
<ul>
        <li><a href="Home.php">Home Page</a></li>
        <li><a href="contact.php">Contact</a></li>
        
            </ul>
        <h2 align='center' style="font-family:Poor Richard">Tinker</h2>
        <h2 align='center' style="font-family:Poor Richard">An eccomerce site where people can order their desire product at an affordable price</h2>
       <h2 align='center' style="font-family:Poor Richard">Contact us if you faced any problem!!!</h2>
    </body>
   <?php 
        include "../include/footer.php";
      ?>
          
</html>