<?php
include('../model/emp.php');


 $error="";

if (isset($_POST['update'])) {


$connection = new pa();
$conobj=$connection->strt();
$nid=$_POST['nid'];
$contact=$_POST['contact'];
//$contact=$_POST['contact'];
$userQuery=$connection->UpdateUser($conobj,"emp",$nid,$_POST['fname'],$_POST['email'],$contact);
if($userQuery==TRUE)
{
    echo "update successful"; 
}
else
{
    echo "could not update";    
}
$connection->CloseCon($conobj);


}


?>
