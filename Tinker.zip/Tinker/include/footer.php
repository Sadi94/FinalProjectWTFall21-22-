<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    .footer {
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: dark gray;
        color: black;
        text-align: center;
    }
    </style>
</head>
<body>
    <div class="footer">
        <h5 align='center' > <span style="color: rgb(0,0,0);"> Copyright © Tinker <?php echo date(2021);?> </span> </h5>
    </div>
</body>
</html>