<!DOCTYPE html>
<html>
  <head>
    <title> Tinker </title>
  </head>
 
 <body>
			<h1 align='center' style="font-family:Algerian">Tinker</h1>
 <table style="width:100%; border:1px solid  #b3b3b3">
    <tr  style="background-color:#04AA6D;">
        <th style="border: 5px solid #04AA6D;"><a style="text-decoration:none; color:#fff;" href="adminlogin.php">Admin</a></th>
        <th style="border: 5px solid #04AA6D;"><a style="text-decoration:none; color:#fff;" href="StoreOwnerlogin.php">Store Owner</a></th>
        <th style="border: 5px solid #04AA6D;"><a style="text-decoration:none; color:#fff;" href="login.php">Customer</a></th>
        <th style="border: 5px solid #04AA6D;"><a style="text-decoration:none; color:#fff;" href="Employee.php">Employee</a></th>
    </tr>
    </table>
<br>
        <h1 align='center' style="font-family:Poor Richard">"Find All in a Single Site "</h1>
        <center><a href="Home.php">
        <h3 align='center' style="font-family:Poor Richard">STAY HOME , STAY SAFE</h3>   
       <div style="background-color: white;">
    <center><font size="3" face="arial" >
        <br><br>
        <a href="aboutUs.php" class='about'>About Us</a><br>
        <br>
        <a href="contactUs.php" class='contact'>Contact </a><br>.
        <br>
        <br>
        <br>
        </font></center>
    </div> 
  </body>
    
</html>